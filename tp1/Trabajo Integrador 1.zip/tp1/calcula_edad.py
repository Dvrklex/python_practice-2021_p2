from datetime import date
def edad(fn):
    hoy = date.today()
    dn, mn, an = fn.split('-')
    dn = int(dn)
    mn = int(mn)
    an = int(an)
    dh = hoy.day
    mh = hoy.month
    ah = hoy.year
    e = ah - an
    if (mn > mh) or (mn == mh and dn > dh):
        e -= 1
    return e

def foo():
    h = date.today()
    print(h)

foo()

if __name__ == '__main__':
    print(edad('03-06-1965'))
